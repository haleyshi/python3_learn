

```python
import pandas as pd
import numpy as np
import matplotlib as plt
import seaborn as sns
%matplotlib inline

data=pd.read_csv('data/train.csv')
data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.columns
```




    Index(['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp',
           'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked'],
          dtype='object')




```python
len(data)
```




    891




```python
data.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
sns.countplot(x='Survived', data=data)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f8c54f39da0>




![png](output_4_1.png)



```python
data.drop(['PassengerId', 'Name'], axis=1, inplace=True)
```


```python
data.columns
```




    Index(['Survived', 'Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Ticket', 'Fare',
           'Cabin', 'Embarked'],
          dtype='object')




```python
g = sns.heatmap(data[['Survived', 'SibSp', 'Parch', 'Age', 'Fare', 'Pclass']].corr(), cmap='RdYlGn', annot=True)
```


![png](output_7_0.png)



```python
Age0 = data[(data['Survived']==0) & (data['Age'].notnull())]['Age']
Age1 = data[(data['Survived']==1) & (data['Age'].notnull())]['Age']
g = sns.kdeplot(Age0, legend=True, shade=True, color='r', label='NotSurvived')
g = sns.kdeplot(Age1, legend=True, shade=True, color='b', label='Survived')
```


![png](output_8_0.png)



```python
g = sns.factorplot(x='Sex', y='Age', data=data, kind='box')
g = sns.factorplot(x='Pclass', y='Age', data=data, kind='box')
```


![png](output_9_0.png)



![png](output_9_1.png)



```python
index = list(data[data['Age'].isnull()].index)
Age_mean = np.mean(data[data['Age'].notnull()]['Age'])
copy_data = data.copy()

for i in index:
    filling_age = np.mean(copy_data[(copy_data['Pclass'] == copy_data.iloc[i]['Pclass'])
                                   & (copy_data['SibSp'] == copy_data.iloc[i]['SibSp'])
                                   & (copy_data['Parch'] == copy_data.iloc[i]['Parch'])
                                   ]['Age'])
    if not np.isnan(filling_age):
        data['Age'].iloc[i] = filling_age
    else:
        data['Age'].iloc[i] = Age_mean
        
g = sns.kdeplot(Age0, legend=True, shade=True, color='r', label='NotSurvived')
g = sns.kdeplot(Age1, legend=True, shade=True, color='b', label='Survived')
```

    /home/shiguohuang/workspaces/python/venv3/lib/python3.5/site-packages/pandas/core/indexing.py:194: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      self._setitem_with_indexer(indexer, value)



![png](output_10_1.png)



```python
data[data['Cabin'].notnull()]['Cabin'].head(10)
```




    1             C85
    3            C123
    6             E46
    10             G6
    11           C103
    21            D56
    23             A6
    27    C23 C25 C27
    31            B78
    52            D33
    Name: Cabin, dtype: object




```python
data['Cabin'].fillna('U', inplace=True)
data['Cabin'] = data['Cabin'].map(lambda i: list(i)[0])

g = sns.factorplot(x='Cabin', y='Survived', data=data, ci=False, kind='bar', order=['A', 'B', 'C', 'D', 'E', 'F', 'T', 'U'])
```


![png](output_12_0.png)



```python
g = sns.countplot(x='Cabin', hue='Pclass', data=data, order=['A', 'B', 'C', 'D', 'E', 'F', 'T', 'U'])
```


![png](output_13_0.png)



```python
g = sns.kdeplot(data[data['Survived']==0]['Fare'], shade=True, label='NotSurvived', color='r')
g = sns.kdeplot(data[data['Survived']==1]['Fare'], shade=True, label='Survived', color='b')
```


![png](output_14_0.png)



```python
print('%.2f' %(data['Fare'].skew()))
```

    4.79



```python
data['Fare'] = data['Fare'].map(lambda i: np.log(i) if i>0 else 0)
g = sns.distplot(data['Fare'])
print('Skew Coefficient: %.2f' %(data['Fare'].skew()))
```

    Skew Coefficient: 0.44



![png](output_16_1.png)



```python
Ticket = []
import re

r = re.compile(r'\w*')

for i in data['Ticket']:
    sp = i.split(' ')
    if len(sp) == 1:
        Ticket.append('U')
    else:
        t = r.findall(sp[0])
        Ticket.append(''.join(t))
        
data['Ticket'] = Ticket
data = pd.get_dummies(data, columns=['Ticket'], prefix='T')
```


```python
data.columns
```




    Index(['Survived', 'Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Cabin',
           'Embarked', 'T_A4', 'T_A5', 'T_AS', 'T_C', 'T_CA', 'T_CASOTON', 'T_FC',
           'T_FCC', 'T_Fa', 'T_PC', 'T_PP', 'T_PPP', 'T_SC', 'T_SCA4', 'T_SCAH',
           'T_SCOW', 'T_SCPARIS', 'T_SCParis', 'T_SOC', 'T_SOP', 'T_SOPP',
           'T_SOTONO2', 'T_SOTONOQ', 'T_SP', 'T_STONO', 'T_STONO2', 'T_SWPP',
           'T_U', 'T_WC', 'T_WEP'],
          dtype='object')




```python
data['Sex'].replace('male', 0, inplace=True)
data['Sex'].replace('female', 1, inplace=True)
```


```python
from collections import Counter

def outlier_detect(n, df, features):
    outlier_index = []
    
    for feature in features:
        Q1 = np.percentile(df[feature], 25)
        Q3 = np.percentile(df[feature], 75)
        
        IRQ = Q3 - Q1
        outlier_span = 1.5 * IRQ
        col = ((data[data[feature] > Q3 + outlier_span]) | 
              (data[data[feature] < Q1 - outlier_span])).index
        outlier_index.extend(col)
        
        print('%s: %f (Q3+1.5*IQR), %f (Q1-1.5*IQR)' %(feature, Q3 + outlier_span, Q1 - outlier_span))
        
    outlier_index = Counter(outlier_index)
    outlier = list(i for i, j in outlier_index.items() if j >= n)
    print('number of outliers: %d' % len(outlier))
    print(df[['Age', 'Parch', 'SibSp', 'Fare']].loc[outlier])
    
    return outlier

outlier = outlier_detect(3, data, ['Age', 'Parch', 'SibSp', 'Fare'])
```

    Age: 59.500000 (Q3+1.5*IQR), -0.500000 (Q1-1.5*IQR)
    Parch: 0.000000 (Q3+1.5*IQR), 0.000000 (Q1-1.5*IQR)
    SibSp: 2.500000 (Q3+1.5*IQR), -1.500000 (Q1-1.5*IQR)
    Fare: 5.482703 (Q3+1.5*IQR), 0.019461 (Q1-1.5*IQR)
    number of outliers: 4
          Age  Parch  SibSp      Fare
    27   19.0      2      3  5.572154
    88   23.0      2      3  5.572154
    341  24.0      2      3  5.572154
    438  64.0      4      1  5.572154

